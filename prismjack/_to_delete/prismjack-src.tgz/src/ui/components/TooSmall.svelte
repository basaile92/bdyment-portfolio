<script lang="ts">
  import type { GameController } from '../GameController.svelte';

  /**
   * Below about 360 × 600 px (portrait) or 560 px high (wide layout), the biggest rooms (9 × 9) get cells
   * under ~26 px and torches under ~16 px: too small to aim. Rather than a broken room, say so plainly.
   * Pure CSS: it appears and disappears as the window is resized.
   */
  let { game }: { game: GameController } = $props();
</script>

{#if game.screen === 'game'}
  <div class="too-small" role="alertdialog" aria-labelledby="too-small-title">
    <div class="card">
      <h2 id="too-small-title">{game.s.tooSmallTitle}</h2>
      <p>{game.s.tooSmallText}</p>
      <button class="btn primary" onclick={() => game.goHome()}>{game.s.backHome}</button>
    </div>
  </div>
{/if}

<style>
  .too-small { display: none; }
  /* Narrow layout (anything but the wide one, from 760 px and landscape) needs 600 px of height; the wide one 560 (its side column holds the coach card and the toolbar). */
  @media (max-width: 359px), (max-height: 599px) and (max-aspect-ratio: 1/1), (max-height: 599px) and (max-width: 759px), (max-height: 559px) {
    .too-small {
      position: fixed; inset: 0; z-index: 50; display: flex; align-items: center; justify-content: center; padding: 16px;
      background: var(--bg);
    }
  }
  .card { max-width: 340px; text-align: center; display: flex; flex-direction: column; gap: 10px; align-items: center; }
  h2 { margin: 0; font-family: var(--title-font); font-weight: 400; font-size: 20px; color: var(--gold); }
  p { margin: 0; font-size: 15px; line-height: 1.4; font-weight: 700; color: var(--ink); }
  .btn { margin-top: 6px; padding: 12px 32px; font-size: 16px; }
</style>
