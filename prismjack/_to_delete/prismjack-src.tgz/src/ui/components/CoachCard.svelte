<script lang="ts">
  import type { GameController } from '../GameController.svelte';
  import Rich from './Rich.svelte';

  /** Playable tutorial: what to do now, and why the last result looked the way it did. Stays until the step is done. */
  let { game }: { game: GameController } = $props();
</script>

{#if game.mode.kind === 'lesson' && game.coachText}
  <aside class="coach" aria-live="polite">
    {#key game.lessonStep}<p class="text"><Rich text={game.coachText} /></p>{/key}
    <div class="foot">
      {#if game.nudged}<p class="nudge"><Rich text={game.s.lessonNudge} /></p>{/if}
      {#if !game.won}<button class="skip" onclick={() => game.start({ kind: 'level', index: 0 })}>{game.s.lessonSkip}</button>{/if}
    </div>
  </aside>
{/if}

<style>
  .coach {
    display: flex; flex-direction: column; gap: 6px; padding: 12px 14px; border-radius: 16px;
    background: #fff; color: #1b1745; box-shadow: 0 6px 18px rgba(0, 0, 0, 0.35); border: 2px solid var(--gold);
  }
  .text { margin: 0; height: 7em; overflow-y: auto; font-size: 15px; line-height: 1.4; font-weight: 700; animation: appear 0.35s ease-out; }
  .text :global(b), .text :global(strong) { color: #1b1745; font-weight: 900; }
  .nudge { margin: 0; font-size: 13px; font-weight: 800; color: #c2185b; }
  .nudge :global(b) { color: inherit; font-weight: 900; }
  /* Fixed height: the board keeps its size whatever the message, so torches never move under the finger. */
  .foot { display: flex; align-items: center; gap: 8px; min-height: 22px; }
  .skip { margin-left: auto; flex-shrink: 0; padding: 2px 4px; border: none; background: none; font-size: 12px; font-weight: 800; color: #6b6f9a; text-decoration: underline; }
  @keyframes appear { from { opacity: 0; transform: translateY(4px); } }
  @media (prefers-reduced-motion: reduce) { .text { animation: none; } }
</style>
